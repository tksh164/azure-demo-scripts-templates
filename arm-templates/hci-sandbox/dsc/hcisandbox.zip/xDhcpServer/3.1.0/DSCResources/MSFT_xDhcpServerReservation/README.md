# Description

The xDhcpServerReservation DSC resource manages lease assignments to
reserv an IP address for a specific client on a subnet.

## Requirements

- Target machine must be running Windows Server 2012 R2 or later.
- Target machine must be running at minimum Windows PowerShell 5.0.
