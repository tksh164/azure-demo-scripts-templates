param($eventGridEvent, $TriggerMetadata)

#Write-Host ('CONTEXT_SUBSCRIPTION_ID: {0}' -f $env:CONTEXT_SUBSCRIPTION_ID)
#Set-AzContext -Subscription $env:CONTEXT_SUBSCRIPTION_ID | Format-List *
Get-AzContext | Format-List *

#Write-Host ('*** $eventGridEvent.data.claims ***')
#$eventGridEvent.data.claims | Format-List *

#Write-Host ('*** $eventGridEvent.data.authorization ***')
#$eventGridEvent.data.authorization | Format-List *

#Write-Host ('*** $eventGridEvent.data.authorization.evidence ***')
#$eventGridEvent.data.authorization.evidence | Format-List *

$caller = $eventGridEvent.data.claims.name
if ($null -eq $caller) {
    if ($eventGridEvent.data.authorization.evidence.principalType -eq 'ServicePrincipal') {
        $caller = (Get-AzADServicePrincipal -ObjectId $eventGridEvent.data.authorization.evidence.principalId).DisplayName
        if ($null -eq $caller) {
            Write-Host 'MSI may not have permission to read the applications from the directory'
            $caller = $eventGridEvent.data.authorization.evidence.principalId
        }
    }
}
$resourceId = $eventGridEvent.data.resourceUri

Write-Host ('Caller: {0}' -f $caller)
Write-Host ('ResourceId: {0}' -f $resourceId)

if (($null -eq $caller) -or ($null -eq $resourceId)) {
    Write-Host 'ResourceId or Caller is null'
    exit;
}

<#
# NOTE: Ignore resource types are filtered using event subscription setting.

$ignoreResourceTypes = @(
    'providers/Microsoft.Resources/deployments',
    'providers/Microsoft.Resources/tags'
)
foreach ($case in $ignoreResourceTypes) {
    if ($resourceId -match $case) {
        Write-Host 'Skipping event as resourceId contains: $case'
        exit;
    }
}
#>

$tags = (Get-AzTag -ResourceId $resourceId).Properties

if (!($tags.TagsProperty.ContainsKey('creator')) -or ($null -eq $tags)) {
    $tag = @{
        'creator' = $caller
        #'created-jst' = (Get-Date).AddHours(9).ToString('yyyyMMdd-HHmm')
        #'created-jst-eg' = $eventGridEvent.eventTime.AddHours(9).ToString('yyyyMMdd-HHmm')
        'created-jst' = $eventGridEvent.eventTime.AddHours(9).ToString('yyyy-MM-dd HH:mm:ss')
    }
    Update-AzTag -ResourceId $resourceId -Operation Merge -Tag $tag
    Write-Host "Added creator tag with user: $caller"
}
else {
    Write-Host "Tag already exists"
}
