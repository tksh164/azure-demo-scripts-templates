param($eventGridEvent, $TriggerMetadata)

Write-Verbose -Message ('CONTEXT_SUBSCRIPTION_ID: {0}' -f $env:CONTEXT_SUBSCRIPTION_ID)
#Set-AzContext -Subscription $env:CONTEXT_SUBSCRIPTION_ID | Format-List *
#Get-AzContext | Format-List *

#Write-Verbose -Message ('*** $eventGridEvent.data.claims ***')
#$eventGridEvent.data.claims | Format-List *

#Write-Verbose -Message ('*** $eventGridEvent.data.authorization ***')
#$eventGridEvent.data.authorization | Format-List *

#Write-Verbose -Message ('*** $eventGridEvent.data.authorization.evidence ***')
#$eventGridEvent.data.authorization.evidence | Format-List *

Write-Verbose -Message ('principalId: {0}' -f $eventGridEvent.data.authorization.evidence.principalId)

$caller = $eventGridEvent.data.claims.name
if ($null -eq $caller) {
    if ($eventGridEvent.data.authorization.evidence.principalType -eq 'ServicePrincipal') {
        $caller = (Get-AzADServicePrincipal -ObjectId $eventGridEvent.data.authorization.evidence.principalId).DisplayName
        if ($null -eq $caller) {
            #Write-Host 'MSI may not have permission to read the applications from the directory'
            Write-Warning -Message 'MSI may not have permission to read the applications from the directory.'
            $caller = $eventGridEvent.data.authorization.evidence.principalId
        }
    }
}
$resourceId = $eventGridEvent.data.resourceUri

Write-Verbose -Message ('Caller: {0}' -f $caller)
Write-Verbose -Message ('ResourceId: {0}' -f $resourceId)

if (($null -eq $caller) -or ($null -eq $resourceId)) {
    Write-Warning -Message 'ResourceId or Caller is null.'
    exit
}

<#
# NOTE: Ignore resource types are filtered using event subscription setting.

$ignoreResourceTypes = @(
    'providers/Microsoft.Resources/deployments',
    'providers/Microsoft.Resources/tags'
)
foreach ($case in $ignoreResourceTypes) {
    if ($resourceId -match $case) {
        Write-Host 'Skipping event as resourceId contains: $case'
        exit;
    }
}
#>

$tags = (Get-AzTag -ResourceId $resourceId).Properties

if (!($tags.TagsProperty.ContainsKey('creator')) -or ($null -eq $tags)) {
    $tag = @{
        'creator' = $caller
        #'created-jst' = (Get-Date).AddHours(9).ToString('yyyyMMdd-HHmm')
        #'created-jst-eg' = $eventGridEvent.eventTime.AddHours(9).ToString('yyyyMMdd-HHmm')
        #'created-jst' = $eventGridEvent.eventTime.AddHours(9).ToString('yyyy-MM-dd HH:mm:ss')
        'created-jst' = $eventGridEvent.eventTime.AddHours(9).ToString('yyyy-MM-dd HH:mm')
    }
    [void](Update-AzTag -ResourceId $resourceId -Operation Merge -Tag $tag)
    Write-Verbose -Message ('Added creator tag with user: {0}' -f $caller)
}
else {
    Write-Verbose -Message 'Tag already exists.'
}
