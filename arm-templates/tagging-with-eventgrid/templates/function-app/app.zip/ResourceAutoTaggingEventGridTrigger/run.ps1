param($eventGridEvent, $TriggerMetadata)

#Write-Host ('*** $eventGridEvent.data.claims ***')
#$eventGridEvent.data.claims | Format-List *

#Write-Host ('*** $eventGridEvent.data.authorization ***')
#$eventGridEvent.data.authorization | Format-List *

#Write-Host ('*** $eventGridEvent.data.authorization.evidence ***')
#$eventGridEvent.data.authorization.evidence | Format-List *


$caller = $eventGridEvent.data.claims.name
if ($null -eq $caller) {
    if ($eventGridEvent.data.authorization.evidence.principalType = "ServicePrincipal") {
        $caller = (Get-AzADServicePrincipal -ObjectId $eventGridEvent.data.authorization.evidence.principalId).DisplayName
        if ($null -eq $caller) {
            Write-Host "MSI may not have permission to read the applications from the directory"
            $caller = $eventGridEvent.data.authorization.evidence.principalId
        }
    }
}
Write-Host "Caller: $caller"
$resourceId = $eventGridEvent.data.resourceUri
Write-Host "ResourceId: $resourceId"

if (($null -eq $caller) -or ($null -eq $resourceId)) {
    Write-Host "ResourceId or Caller is null"
    exit;
}

$ignore = @("providers/Microsoft.Resources/deployments", "providers/Microsoft.Resources/tags")

foreach ($case in $ignore) {
    if ($resourceId -match $case) {
        Write-Host "Skipping event as resourceId contains: $case"
        exit;
    }
}

$tags = (Get-AzTag -ResourceId $resourceId).Properties

if (!($tags.TagsProperty.ContainsKey('creator')) -or ($null -eq $tags)) {
    $tag = @{
        'creator' = $caller
        #'created-jst' = (Get-Date).AddHours(9).ToString('yyyyMMdd-HHmm')
        #'created-jst-eg' = $eventGridEvent.eventTime.AddHours(9).ToString('yyyyMMdd-HHmm')
        'created-jst' = $eventGridEvent.eventTime.AddHours(9).ToString('yyyy-MM-dd HH:mm:ss')
    }
    Update-AzTag -ResourceId $resourceId -Operation Merge -Tag $tag
    Write-Host "Added creator tag with user: $caller"
}
else {
    Write-Host "Tag already exists"
}
