# Description

The ADReplicationSubnet DSC resource will manage replication subnets.

## Requirements

* Target machine must be running Windows Server 2008 R2 or later.
