Configuration aksonwshost {
    param (
        [Parameter(Mandatory = $true)]
        [string] $DomainName,

        [Parameter(Mandatory = $true)]
        [string] $Environment,

        [Parameter(Mandatory = $true)]
        [System.Management.Automation.PSCredential] $AdminCreds,

        [Parameter(Mandatory = $true)]
        [string] $EnableDHCP,

        [Parameter(Mandatory = $true)]
        [string] $CustomRdpPort,

        [Parameter(Mandatory = $false)]
        [string] $VSwitchNameHost = 'InternalNAT',

        [Parameter(Mandatory = $false)]
        [string] $TargetDrive = 'V',

        [Parameter(Mandatory = $false)]
        [string] $SourcePath = [IO.Path]::Combine($TargetDrive + ':\', 'Source'),

        [Parameter(Mandatory = $false)]
        [string] $UpdatePath = [IO.Path]::Combine($SourcePath, 'Updates'),

        [Parameter(Mandatory = $false)]
        [string] $SsuPath = [IO.Path]::Combine($UpdatePath, 'SSU'),

        [Parameter(Mandatory = $false)]
        [string] $CuPath = [IO.Path]::Combine($UpdatePath, 'CU'),

        [Parameter(Mandatory = $false)]
        [string] $TargetVMPath = [IO.Path]::Combine($TargetDrive + ':\', 'VMs'),

        [Parameter(Mandatory = $false)]
        [string] $WitnessPath = [IO.Path]::Combine($TargetDrive + ':\', 'Witness'),

        [Parameter(Mandatory = $false)]
        [string] $TargetADPath = [IO.Path]::Combine($TargetDrive + ':\', 'ADDS'),

        [Parameter(Mandatory = $false)]
        [string] $BaseVHDFolderPath = [IO.Path]::Combine($TargetVMPath, 'Base'),

        [Parameter(Mandatory = $false)]
        #[string] $IsoFileUri = 'https://go.microsoft.com/fwlink/p/?LinkID=2195280&clcid=0x409&culture=en-us&country=US',  # Windows Server 2022 Evaluation en-US
        [string] $IsoFileUri = 'https://go.microsoft.com/fwlink/p/?LinkID=2195280&clcid=0x411&culture=ja-jp&country=JP',  # Windows Server 2022 Evaluation ja-JP

        [Parameter(Mandatory = $false)]
        [int] $WimImageIndex = 4,
        # 1: Windows Server 2022 Standard Evaluation
        # 2: Windows Server 2022 Standard Evaluation (Desktop Experience)
        # 3: Windows Server 2022 Datacenter Evaluation
        # 4: Windows Server 2022 Datacenter Evaluation (Desktop Experience)

        [Parameter(Mandatory = $false)]
        [string] $NestedVMVhdPath = [IO.Path]::Combine($BaseVHDFolderPath, 'windows-server.vhdx'),

        [Parameter(Mandatory = $false)]
        [string] $LocalIsoFilePath = [IO.Path]::Combine($SourcePath, 'windows-server.iso'),

        [Parameter(Mandatory = $false)]
        [int] $NumOfNestedVM = 2,

        [Parameter(Mandatory = $false)]
        [int] $NestedVMDataDiskCount = 4,

        [Parameter(Mandatory = $false)]
        [long] $NestedVMDataDiskSize = 250GB
    )
    
    Import-DscResource -ModuleName 'PSDesiredStateConfiguration'
    Import-DscResource -ModuleName 'xPSDesiredStateConfiguration'
    Import-DscResource -ModuleName 'ComputerManagementDsc'
    Import-DscResource -ModuleName 'xHyper-v'
    Import-DscResource -ModuleName 'cHyper-v'
    Import-DscResource -ModuleName 'StorageDSC'
    Import-DscResource -ModuleName 'NetworkingDSC'
    Import-DscResource -ModuleName 'xDHCpServer'
    Import-DscResource -ModuleName 'DnsServerDsc'
    Import-DscResource -ModuleName 'cChoco'
    Import-DscResource -ModuleName 'DSCR_Shortcut'
    Import-DscResource -ModuleName 'xCredSSP'
    Import-DscResource -ModuleName 'ActiveDirectoryDsc'

    $nestedVMDscScriptUri = 'https://raw.githubusercontent.com/tksh164/azure-demo-scripts-templates/master/arm-templates/aks-on-windows-server-lab/dsc/helpers/dsc-config-for-nested-vm.ps1'
    $updateAddsScriptUri = 'https://raw.githubusercontent.com/tksh164/azure-demo-scripts-templates/master/arm-templates/aks-on-windows-server-lab/dsc/helpers/update-adds-config.ps1'

    #$dhcpStatus = if ($enableDHCP -eq 'Enabled') { 'Active' } else { 'Inactive' }

    #[System.Management.Automation.PSCredential] $domainCreds = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($Admincreds.UserName)", $Admincreds.Password)
    $domainCreds = New-Object -TypeName 'System.Management.Automation.PSCredential' -ArgumentList ('{0}\{1}' -f $DomainName, $AdminCreds.UserName), $AdminCreds.Password

    # Find a network adapter that has IPv4 default gateway.
    $interfaceAlias = (Get-NetAdapter -Physical -InterfaceDescription 'Microsoft Hyper-V Network Adapter*' | Get-NetIPConfiguration | Where-Object -Property 'IPv4DefaultGateway' | Sort-Object -Property 'InterfaceIndex' | Select-Object -First 1).InterfaceAlias

    # $ipConfig = (Get-NetAdapter -Physical | Where-Object { $_.InterfaceDescription -like '*Hyper-V*' } | Get-NetIPConfiguration | Where-Object IPv4DefaultGateway)
    # $netAdapters = Get-NetAdapter -Name ($ipConfig.InterfaceAlias) | Select-Object -First 1
    # $interfaceAlias = $($netAdapters.Name)

    Node 'localhost' {
        LocalConfigurationManager {
            ConfigurationMode  = 'ApplyOnly'
            RebootNodeIfNeeded = $true
            ActionAfterReboot  = 'ContinueConfiguration'
        }

        #### CREATE STORAGE SPACES V: & VM FOLDER ####

        $storagePoolName = 'aksonwspool'
        $volumeLabel = 'aksonws-data'
    
        Script 'StoragePool' {
            GetScript = {
                @{ Result = if ([scriptblock]::Create($TestScript).Invoke()) { 'Present' } else { 'Absent' } }
            }
            SetScript = {
                New-StoragePool -FriendlyName $using:storagePoolName -StorageSubSystemFriendlyName '*storage*' -PhysicalDisks (Get-PhysicalDisk -CanPool $true)
            }
            TestScript = {
                (Get-StoragePool -FriendlyName $using:storagePoolName -ErrorAction SilentlyContinue).OperationalStatus -eq 'OK'
            }
        }

        Script 'Volume' {
            GetScript = {
                @{ Result = if ([scriptblock]::Create($TestScript).Invoke()) { 'Present' } else { 'Absent' } }
            }
            SetScript = {
                New-Volume -StoragePoolFriendlyName $using:storagePoolName -FileSystem NTFS -AllocationUnitSize 64KB -ResiliencySettingName Simple -UseMaximumSize -DriveLetter $using:TargetDrive -FriendlyName $using:volumeLabel
            }
            TestScript = {
                (Get-Volume -DriveLetter $using:TargetDrive -ErrorAction SilentlyContinue).OperationalStatus -eq 'OK'
            }
        }

        File 'Source' {
            DestinationPath = $SourcePath
            Type            = 'Directory'
            Force           = $true
            DependsOn       = '[Script]Volume'
        }

        File 'Updates' {
            DestinationPath = $UpdatePath
            Type            = 'Directory'
            Force           = $true
            DependsOn       = '[File]Source'
        }

        File 'CU' {
            DestinationPath = $CuPath
            Type            = 'Directory'
            Force           = $true
            DependsOn       = '[File]Updates'
        }

        File 'SSU' {
            DestinationPath = $SsuPath
            Type            = 'Directory'
            Force           = $true
            DependsOn       = '[File]Updates'
        }

        File 'VMFolder' {
            Type            = 'Directory'
            DestinationPath = $TargetVMPath
            DependsOn       = '[Script]Volume'
        }

        File 'VMBase' {
            Type            = 'Directory'
            DestinationPath = $BaseVHDFolderPath
            DependsOn       = '[File]VMFolder'
        }

        File 'WitnessFolder' {
            Type            = 'Directory'
            DestinationPath = $WitnessPath
            DependsOn       = '[Script]Volume'
        }

        if ($environment -eq 'AD Domain') {
            File 'ADFolder' {
                Type            = 'Directory'
                DestinationPath = $TargetADPath
                DependsOn       = '[Script]Volume'
            }
        }

        Script 'Download DSC config script for nested VM' {
            GetScript = {
                @{ Result = if ([scriptblock]::Create($TestScript).Invoke()) { 'Present' } else { 'Absent' } }
            }
            SetScript = {
                Start-BitsTransfer -Source $using:nestedVMDscScriptUri -Destination ([IO.Path]::Combine($using:SourcePath, 'dsc-config-for-nested-vm.ps1'))
            }
            TestScript = {
                Test-Path -Path ([IO.Path]::Combine($using:SourcePath, 'dsc-config-for-nested-vm.ps1'))
            }
            DependsOn = '[File]Source'
        }

        Script 'Download update AD DS configuration script' {
            GetScript = {
                @{ Result = if ([scriptblock]::Create($TestScript).Invoke()) { 'Present' } else { 'Absent' } }
            }
            SetScript = {
                Start-BitsTransfer -Source $using:updateAddsScriptUri -Destination ([IO.Path]::Combine($using:SourcePath, 'update-adds-config.ps1'))        
            }
            TestScript = {
                Test-Path -Path ([IO.Path]::Combine($using:SourcePath, 'update-adds-config.ps1'))
            }
            DependsOn = '[File]Source'
        }

        Script 'Download ISO file' {
            GetScript = {
                @{ Result = if ([scriptblock]::Create($TestScript).Invoke()) { 'Present' } else { 'Absent' } }
            }
            SetScript = {
                Start-BitsTransfer -Source $using:IsoFileUri -Destination $using:LocalIsoFilePath
            }
            TestScript = {
                Test-Path -Path $using:LocalIsoFilePath
            }
            DependsOn = '[File]Source'
        }

        <#
        Script 'Download AzSHCI SSU' {
            GetScript = {
                $result = Test-Path -Path "$using:SsuPath\*" -Include "*.msu"
                @{ Result = $result }
            }
            SetScript = {
                $ssuSearchString = "Servicing Stack Update for Azure Stack HCI, version 21H2 for x64-based Systems"
                $ssuID = "Azure Stack HCI"
                $ssuUpdate = Get-MSCatalogUpdate -Search $ssuSearchString | Where-Object Products -eq $ssuID | Select-Object -First 1
                $ssuUpdate | Save-MSCatalogUpdate -Destination $using:SsuPath
            }
            TestScript = {
                # Create and invoke a scriptblock using the $GetScript automatic variable, which contains a string representation of the GetScript.
                $state = [scriptblock]::Create($GetScript).Invoke()
                $state.Result
            }
            DependsOn = '[File]SSU'
        }
        #>

        <#
        Script 'Download AzSHCI CU' {
            GetScript = {
                $result = Test-Path -Path "$using:CuPath\*" -Include "*.msu"
                @{ Result = $result }
            }
            SetScript = {
                $cuSearchString = "Cumulative Update for Azure Stack HCI, version 21H2"
                $cuID = "Azure Stack HCI"
                $cuUpdate = Get-MSCatalogUpdate -Search $cuSearchString | Where-Object Products -eq $cuID | Where-Object Title -like "*$($cuSearchString)*" | Select-Object -First 1
                $cuUpdate | Save-MSCatalogUpdate -Destination $using:CuPath
            }
            TestScript = {
                # Create and invoke a scriptblock using the $GetScript automatic variable, which contains a string representation of the GetScript.
                $state = [scriptblock]::Create($GetScript).Invoke()
                $state.Result
            }
            DependsOn = '[File]CU'
        }
        #>

        #### SET WINDOWS DEFENDER EXCLUSION FOR VM STORAGE ####

        $exclusionPath = $TargetDrive + ':\'

        Script 'Defender Exclusions' {
            GetScript = {
                @{ Result = if ([scriptblock]::Create($TestScript).Invoke()) { 'Present' } else { 'Absent' } }
            }
            SetScript = {
                Add-MpPreference -ExclusionPath $using:exclusionPath      
            }
            TestScript = {
                (Get-MpPreference).ExclusionPath -contains $using:exclusionPath
            }
            DependsOn  = '[Script]Volume'
        }

        #### REGISTRY & SCHEDULED TASK TWEAKS ####

        Registry 'Disable Internet Explorer ESC for Admin' {
            Ensure    = 'Present'
            Key       = 'HKLM:\SOFTWARE\Microsoft\Active Setup\Installed Components\{A509B1A7-37EF-4b3f-8CFC-4F3A74704073}'
            ValueName = 'IsInstalled'
            ValueType = 'Dword'
            ValueData = '0'
        }

        Registry 'Disable Internet Explorer ESC for User' {
            Ensure    = 'Present'
            Key       = 'HKLM:\SOFTWARE\Microsoft\Active Setup\Installed Components\{A509B1A8-37EF-4b3f-8CFC-4F3A74704073}'
            ValueName = 'IsInstalled'
            ValueType = 'Dword'
            ValueData = '0'
        }
        
        Registry 'Disable Server Manager WAC Prompt' {
            Ensure    = 'Present'
            Key       = 'HKLM:\SOFTWARE\Microsoft\ServerManager'
            ValueName = 'DoNotPopWACConsoleAtSMLaunch'
            ValueType = 'Dword'
            ValueData = '1'
        }

        Registry 'Disable Network Profile Prompt' {
            Ensure    = 'Present'
            Key       = 'HKLM:\System\CurrentControlSet\Control\Network\NewNetworkWindowOff'
            ValueName = ''
        }

        if ($environment -eq 'Workgroup') {
            Registry 'Set Network Private Profile Default' {
                Ensure    = 'Present'
                Key       = 'HKLM:\SOFTWARE\Policies\Microsoft\Windows NT\CurrentVersion\NetworkList\Signatures\010103000F0000F0010000000F0000F0C967A3643C3AD745950DA7859209176EF5B87C875FA20DF21951640E807D7C24'
                ValueName = 'Category'
                ValueType = 'Dword'
                ValueData = '1'
            }
    
            Registry 'SetWorkgroupDomain' {
                Ensure    = 'Present'
                Key       = 'HKLM:\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters'
                ValueName = 'Domain'
                ValueType = 'String'
                ValueData = $DomainName
            }
    
            Registry 'SetWorkgroupNVDomain' {
                Ensure    = 'Present'
                Key       = 'HKLM:\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters'
                ValueName = 'NV Domain'
                ValueType = 'String'
                ValueData = $DomainName
            }
    
            Registry 'NewCredSSPKey' {
                Ensure    = 'Present'
                Key       = 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\CredentialsDelegation\AllowFreshCredentialsWhenNTLMOnly'
                ValueName = ''
            }
    
            Registry 'NewCredSSPKey2' {
                Ensure    = 'Present'
                Key       = 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\CredentialsDelegation'
                ValueName = 'AllowFreshCredentialsWhenNTLMOnly'
                ValueType = 'Dword'
                ValueData = '1'
                DependsOn = '[Registry]NewCredSSPKey'
            }
    
            Registry 'NewCredSSPKey3' {
                Ensure    = 'Present'
                Key       = 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\CredentialsDelegation\AllowFreshCredentialsWhenNTLMOnly'
                ValueName = '1'
                ValueType = 'String'
                ValueData = '*.{0}' -f $DomainName
                DependsOn = '[Registry]NewCredSSPKey2'
            }
        }

        ScheduledTask 'Disable Server Manager at Startup' {
            TaskPath = '\Microsoft\Windows\Server Manager'
            TaskName = 'ServerManager'
            Enable   = $false
        }

        #### CUSTOM FIREWALL ####

        if ($CustomRdpPort -ne '3389') {
            Registry 'Set custom RDP port' {
                Ensure    = 'Present'
                Key       = 'HKLM:\SYSTEM\CurrentControlSet\Control\Terminal Server\WinStations\RDP-Tcp'
                ValueName = 'PortNumber'
                ValueData = $CustomRdpPort
                ValueType = 'Dword'
            }
        
            Firewall 'Csutom RDP port' {
                Ensure      = 'Present'
                Name        = 'RemoteDesktop-CustomPort-In-TCP'
                DisplayName = 'Remote Desktop with csutom port (TCP-In)'
                Profile     = 'Any'
                Direction   = 'Inbound'
                LocalPort   = $CustomRdpPort
                Protocol    = 'TCP'
                Description = 'Firewall Rule for Custom RDP Port'
                Enabled     = 'True'
            }
        }

        Firewall 'WAC inbound rule' {
            Ensure      = 'Present'
            Name        = 'WAC-HTTPS-In-TCP'
            DisplayName = 'Windows Admin Center (HTTPS-In)'
            Profile     = 'Any'
            Direction   = 'Inbound'
            LocalPort   = "443"
            Protocol    = 'TCP'
            Description = 'Inbound rule for Windows Admin Center'
            Enabled     = 'True'
        }

        Firewall 'WAC outbound rule' {
            Ensure      = 'Present'
            Name        = 'WAC-HTTPS-Out-TCP'
            DisplayName = 'Windows Admin Center (HTTPS-Out)'
            Profile     = 'Any'
            Direction   = 'Outbound'
            LocalPort   = "443"
            Protocol    = 'TCP'
            Description = 'Outbound rule for Windows Admin Center'
            Enabled     = 'True'
        }

        #### ENABLE ROLES & FEATURES ####

        WindowsFeatureSet 'Install roles and features' {
            Ensure = 'Present'
            Name = @(
                'DNS',
                'RSAT-DNS-Server',
                'DHCP',
                'RSAT-DHCP',
                'RSAT-Clustering',
                'Hyper-V',
                'RSAT-Hyper-V-Tools',
                'FS-Data-Deduplication'
            )
        }

        Script 'Enable DNS diags' {
            GetScript = { @{ Result = '' } }
            SetScript = { 
                Set-DnsServerDiagnostics -All $true
                Write-Verbose -Verbose 'Enabling DNS client diagnostics'
            }
            TestScript = { $false }
            DependsOn = '[WindowsFeatureSet]Install roles and features'
        }

        DnsServerAddress "DnsServerAddress for $interfaceAlias" {
            Address        = '127.0.0.1'
            InterfaceAlias = $interfaceAlias
            AddressFamily  = 'IPv4'
            DependsOn      = '[WindowsFeatureSet]Install roles and features'
        }

        Registry 'DHCP config complete' {
            Ensure    = 'Present'
            Key       = 'HKLM:\SOFTWARE\Microsoft\ServerManager\Roles\12'
            ValueName = 'ConfigurationState'
            ValueType = 'Dword'
            ValueData = '2'
            DependsOn = '[WindowsFeatureSet]Install roles and features'
        }

        if ($environment -eq 'AD Domain') {
            WindowsFeatureSet 'Install AD DS' {
                Ensure = 'Present'
                Name = @(
                    'AD-Domain-Services',
                    'RSAT-ADDS-Tools',
                    'RSAT-AD-AdminCenter'
                )
                DependsOn = '[WindowsFeatureSet]Install roles and features'
            }

            ADDomain 'Create first DC' {
                DomainName                    = $DomainName
                Credential                    = $domainCreds
                SafemodeAdministratorPassword = $domainCreds
                DatabasePath                  = [IO.Path]::Combine($TargetADPath, 'NTDS')
                LogPath                       = [IO.Path]::Combine($TargetADPath, 'NTDS')
                SysvolPath                    = [IO.Path]::Combine($TargetADPath, 'SYSVOL')
                DependsOn                     = @(
                    '[File]ADFolder',
                    '[WindowsFeatureSet]Install AD DS'
                )
            }
        }

        #### HYPER-V vSWITCH CONFIG ####

        xVMHost 'Hyper-V Host'
        {
            IsSingleInstance          = 'yes'
            EnableEnhancedSessionMode = $true
            VirtualHardDiskPath       = $TargetVMPath
            VirtualMachinePath        = $TargetVMPath
            DependsOn                 = '[WindowsFeatureSet]Install roles and features'
        }

        xVMSwitch 'Create NAT vSwitch'
        {
            Name      = $VSwitchNameHost
            Type      = 'Internal'
            DependsOn = '[WindowsFeatureSet]Install roles and features'
        }

        $natInterfaceName = 'vEthernet ({0})' -f $VSwitchNameHost

        IPAddress 'Assign IP address for NAT network interface'
        {
            InterfaceAlias = $natInterfaceName
            AddressFamily  = 'IPv4'
            IPAddress      = '192.168.0.1/16'
            DependsOn      = '[xVMSwitch]Create NAT vSwitch'
        }

        NetIPInterface 'Enable IP forwarding on NAT network interface'
        {   
            AddressFamily  = 'IPv4'
            InterfaceAlias = $natInterfaceName
            Forwarding     = 'Enabled'
            DependsOn      = '[IPAddress]Assign IP address for NAT network interface'
        }

        NetAdapterRdma 'Enable RDMA on NAT network interface'
        {
            Name      = $natInterfaceName
            Enabled   = $true
            DependsOn = '[NetIPInterface]Enable IP forwarding on NAT network interface'
        }

        DnsServerAddress 'Set DNS server address for NAT network interface'
        { 
            Address        = '127.0.0.1' 
            InterfaceAlias = $natInterfaceName
            AddressFamily  = 'IPv4'
            DependsOn      = '[IPAddress]Assign IP address for NAT network interface'
        }

        if ($environment -eq 'AD Domain') {
            xDhcpServerAuthorization 'Authorize DHCP server' {
                Ensure    = 'Present'
                DnsName   = [System.Net.Dns]::GetHostByName($env:computerName).hostname
                IPAddress = '192.168.0.1'
                DependsOn = '[WindowsFeatureSet]Install roles and features'
            }
        }
        elseif ($environment -eq 'Workgroup') {
            NetConnectionProfile 'Set network connection profile' {
                InterfaceAlias  = $interfaceAlias
                NetworkCategory = 'Private'
            }
        }

        #### PRIMARY NIC CONFIG ####

        NetAdapterBinding 'Disable IPv6 on host network interface' {
            InterfaceAlias = $interfaceAlias
            ComponentId    = 'ms_tcpip6'
            State          = 'Disabled'
        }

        #### CONFIGURE Interna NAT NIC

        $netNatName = 'lab-nat'

        Script 'Create network NAT' {
            GetScript = {
                @{ Result = if ([scriptblock]::Create($TestScript).Invoke()) { 'Present' } else { 'Absent' } }
            }
            SetScript = {
                New-NetNat -Name $using:netNatName -InternalIPInterfaceAddressPrefix '192.168.0.0/16'
            }
            TestScript = {
                if (Get-NetNat -Name $using:netNatName -ErrorAction SilentlyContinue) { $true } else { $false }
            }
            DependsOn = '[IPAddress]Assign IP address for NAT network interface'
        }

        NetAdapterBinding 'Disable IPv6 on NAT network interface' {
            InterfaceAlias = $natInterfaceName
            ComponentId    = 'ms_tcpip6'
            State          = 'Disabled'
            DependsOn      = '[Script]Create network NAT'
        }

        #### CONFIGURE DHCP SERVER

        xDhcpServerScope 'Create DHCP scope' { 
            Ensure        = 'Present'
            IPStartRange  = '192.168.0.10'
            IPEndRange    = '192.168.0.149' 
            ScopeId       = '192.168.0.0'
            Name          = 'Lab Range'
            SubnetMask    = '255.255.0.0'
            LeaseDuration = '01.00:00:00'
            State         = if ($EnableDHCP -eq 'Enabled') { 'Active' } else { 'Inactive' }
            AddressFamily = 'IPv4'
            DependsOn     = @(
                '[WindowsFeatureSet]Install roles and features',
                '[IPAddress]Assign IP address for NAT network interface'
            )
        }

        xDhcpServerOption 'Set DHCP server option' { 
            Ensure             = 'Present' 
            ScopeID            = '192.168.0.0' 
            DnsDomain          = $DomainName
            DnsServerIPAddress = '192.168.0.1'
            AddressFamily      = 'IPv4'
            Router             = '192.168.0.1'
            DependsOn          = '[xDhcpServerScope]Create DHCP scope'
        }

        if ($environment -eq 'AD Domain') {
            DnsServerPrimaryZone 'Set reverse lookup zone' {
                Ensure    = 'Present'
                Name      = '0.168.192.in-addr.arpa'
                ZoneFile  = '0.168.192.in-addr.arpa.dns'
                DependsOn = '[ADDomain]Create first DC'
            }
        }
        elseif ($environment -eq 'Workgroup') {
            DnsServerPrimaryZone 'Set primary DNS zone' {
                Ensure        = 'Present'
                Name          = $DomainName
                ZoneFile      = $DomainName + '.dns'
                DynamicUpdate = 'NonSecureAndSecure'
                DependsOn     = '[Script]Create network NAT'
            }
    
            DnsServerPrimaryZone 'Set reverse lookup zone' {
                Ensure        = 'Present'
                Name          = '0.168.192.in-addr.arpa'
                ZoneFile      = '0.168.192.in-addr.arpa.dns'
                DynamicUpdate = 'NonSecureAndSecure'
                DependsOn     = '[DnsServerPrimaryZone]Set primary DNS zone'
            }
        }

        #### FINALIZE DHCP

        Script 'Set DHCP DNS Setting' {
            GetScript = { @{ Result = '' } }
            SetScript = {
                Set-DhcpServerv4DnsSetting -DynamicUpdates Always -DeleteDnsRRonLeaseExpiry $true -UpdateDnsRRForOlderClients $true -DisableDnsPtrRRUpdate $false
                Write-Verbose -Verbose 'Setting server level DNS dynamic update configuration settings'
            }
            TestScript = { $false }
            DependsOn = '[xDhcpServerOption]Set DHCP server option'
        }

        if ($environment -eq 'Workgroup') {
            DnsConnectionSuffix 'Add specific suffix to host network interface' {
                InterfaceAlias           = $interfaceAlias
                ConnectionSpecificSuffix = $DomainName
                DependsOn                = '[DnsServerPrimaryZone]Set primary DNS zone'
            }
    
            DnsConnectionSuffix 'Add specific suffix to NAT network interface' {
                InterfaceAlias           = $natInterfaceName
                ConnectionSpecificSuffix = $DomainName
                DependsOn                = '[DnsServerPrimaryZone]Set primary DNS zone'
            }

            #### CONFIGURE CREDSSP & WinRM

            xCredSSP 'Set CredSSD Server settings' {
                Ensure         = 'Present'
                Role           = 'Server'
                SuppressReboot = $true
                DependsOn      = '[DnsConnectionSuffix]Add specific suffix to NAT network interface'
            }

            xCredSSP 'Set CredSSD Client settings' {
                Ensure            = 'Present'
                Role              = 'Client'
                DelegateComputers = '{0}.{1}' -f $env:ComputerName, $DomainName
                SuppressReboot    = $true
                DependsOn         = '[xCredSSP]Set CredSSD Server settings'
            }

            #### CONFIGURE WinRM

            $expectedTrustedHost = '*.{0}' -f $DomainName

            Script 'Configure WinRM' {
                GetScript = {
                    @{ Result = if ([scriptblock]::Create($TestScript).Invoke()) { 'Present' } else { 'Absent' } }
                }
                SetScript = {
                    Set-Item -LiteralPath 'WSMan:\localhost\Client\TrustedHosts' -Value $using:expectedTrustedHost -Force
                }
                TestScript = {
                    (Get-Item -LiteralPath 'WSMan:\localhost\Client\TrustedHosts').Value -contains $using:expectedTrustedHost
                }
                DependsOn = '[xCredSSP]Set CredSSD Client settings'
            }
        }

        #### Start nested VM creation ####

        Script 'Create OS base VHDX file' {
            GetScript = {
                @{ Result = if ([scriptblock]::Create($TestScript).Invoke()) { 'Present' } else { 'Absent' } }
            }
            SetScript = {
                # Create netsted VM image from ISO.
                $params = @{
                    SourcePath        = $using:LocalIsoFilePath
                    Edition           = $using:WimImageIndex
                    VHDPath           = $using:NestedVMVhdPath
                    VHDFormat         = 'VHDX'
                    VHDType           = 'Dynamic'
                    VHDPartitionStyle = 'GPT'
                    SizeBytes         = 100GB
                    TempDirectory     = $using:TargetVMPath
                    Verbose           = $true
                }
                if (Test-Path -Path ([IO.Path]::Combine($using:SsuPath, '*')) -Include '*.msu') {
                    $params.Package = $using:SsuPath
                }
                Convert-WindowsImage @params

                # Need to wait for disk to fully unmount.
                while ((Get-Disk).Count -gt 2) { Start-Sleep -Seconds 5 }

                # Apply update packages to the VHDX.
                $updatePackageFilePaths = Get-ChildItem -Path $using:CuPath -Recurse |
                    Where-Object -FilterScript { ($_.Extension -eq '.msu') -or ($_.Extension -eq '.cab') } |
                    Select-Object -Property 'FullName'

                if ($updatePackageFilePaths) {
                    $mountResult = Mount-DiskImage -ImagePath $using:NestedVMVhdPath -StorageType VHDX -Access ReadWrite -ErrorAction Stop
                    $vhdxWinPartition = Get-Partition -DiskNumber $mountResult.Number | Where-Object -Property 'Type' -EQ -Value 'Basic' | Select-Object -First 1
                    $updatePackageFilePaths | ForEach-Object -Process {
                        Write-Debug -Message $_.FullName
                        $command = 'dism.exe /image:"{0}:\" /Add-Package /PackagePath:"{1}"' -f $vhdxWinPartition.DriveLetter, $_.FullName
                        Write-Debug -Message $command
                        Invoke-Expression -Command $command
                    }
                    Dismount-DiskImage -ImagePath $mountResult.ImagePath
                }

                # Enable Hyper-V role on the nested VM VHD.
                Install-WindowsFeature -Name 'Hyper-V' -Vhd $using:NestedVMVhdPath
            }
            TestScript = {
                Test-Path -Path $using:NestedVMVhdPath -PathType Leaf
            }
            DependsOn = @(
                '[File]VMBase',
                '[Script]Download ISO file'#,
                #'[Script]Download AzSHCI SSU',
                #'[Script]Download AzSHCI CU'
            )
        }

        #for ($nestedVMCount = 0; $nestedVMCount -lt $NumOfNestedVM; $nestedVMCount++) {


        1..$NumOfNestedVM | ForEach-Object -Process {

            $nestedVMName = 'wsfcnode{0:D2}' -f $nestedVMCount
            $nestedVMStoreFolderPath = [IO.Path]::Combine($TargetVMPath, $nestedVMName)

            File "Create VM store folder for $nestedVMName" {
                Ensure          = 'Present'
                DestinationPath = $nestedVMStoreFolderPath
                Type            = 'Directory'
                DependsOn       = '[File]VMFolder'
            }
            
            $osDiskFileName = '{0}-osdisk.vhdx' -f $nestedVMName
            $osDiskFilePath = [IO.Path]::Combine($nestedVMStoreFolderPath, $osDiskFileName)

            xVHD "Create OS disk for $nestedVMName" {
                Ensure     = 'Present'
                Name       = $osDiskFileName
                Path       = $nestedVMStoreFolderPath
                Generation = 'vhdx'
                Type       = 'Differencing'
                ParentPath = $NestedVMVhdPath
                DependsOn  = @(
                    '[xVMSwitch]Create NAT vSwitch',
                    '[Script]Create OS base VHDX file',
                    "[File]Create VM store folder for $nestedVMName"
                )
            }

            xVMHyperV "Create VM $nestedVMName" {
                Ensure         = 'Present'
                Name           = $nestedVMName
                Path           = $TargetVMPath
                Generation     = 2
                ProcessorCount = 8
                StartupMemory  = 24GB
                VhdPath        = $osDiskFilePath
                DependsOn      = "[xVHD]Create OS disk for $nestedVMName"
            }

            xVMProcessor "Enable nested virtualization on $nestedVMName" {
                VMName                         = $nestedVMName
                ExposeVirtualizationExtensions = $true
                DependsOn                      = "[xVMHyperV]Create VM $nestedVMName"
            }

            # Add data disks.
            1..$NestedVMDataDiskCount | ForEach-Object -Process {
                $num = $_
                $dataDiskFileName = '{0}-datadisk{1}.vhdx' -f $nestedVMName, $num

                xVHD "Create data disk $dataDiskFileName" {
                    Ensure           = 'Present'
                    Name             = $dataDiskFileName
                    Path             = $nestedVMStoreFolderPath
                    Generation       = 'vhdx'
                    Type             = 'Dynamic'
                    MaximumSizeBytes = $NestedVMDataDiskSize
                    DependsOn        = "[xVMHyperV]Create VM $nestedVMName"
                }
            
                xVMHardDiskDrive "Add data disk $dataDiskFileName to $nestedVMName" {
                    Ensure             = 'Present'
                    VMName             = $nestedVMName
                    ControllerType     = 'SCSI'
                    ControllerLocation = $num
                    Path               = [IO.Path]::Combine($nestedVMStoreFolderPath, $dataDiskFileName)
                    DependsOn          = "[xVMHyperV]Create VM $nestedVMName"
                }
            }

            Script "Remove default network adapter on $nestedVMName" {
                GetScript = {
                    @{ Result = if ([scriptblock]::Create($TestScript).Invoke()) { 'Removed as expected' } else { 'Exists against expectation' } }
                }
                SetScript = {
                    $networkAdapter = Get-VMNetworkAdapter -VMName $using:nestedVMName -Name 'Network Adapter'
                    Remove-VMNetworkAdapter -VMName $networkAdapter.VMName -Name $networkAdapter.Name                 
                }
                TestScript = {
                    if (Get-VMNetworkAdapter -VMName $using:nestedVMName -Name 'Network Adapter' -ErrorAction SilentlyContinue) { $false } else { $true }
                }
                DependsOn = "[xVMHyperV]Create VM $nestedVMName"
            }

            # Add management network adapters.
            1 | ForEach-Object -Process {
                $num = $_
                $mgmtNetAdapterName = '{0}-Management{1}' -f $nestedVMName, $num

                xVMNetworkAdapter "Add network adapter $mgmtNetAdapterName to $nestedVMName" {
                    Ensure         = 'Present'
                    VMName         = $nestedVMName
                    SwitchName     = $VSwitchNameHost
                    Id             = $mgmtNetAdapterName
                    Name           = $mgmtNetAdapterName
                    NetworkSetting = xNetworkSettings {
                        IpAddress      = '192.168.0.{0}' -f ($nestedVMCount + 1)
                        Subnet         = '255.255.0.0'
                        DefaultGateway = '192.168.0.1'
                        DnsServer      = '192.168.0.1'
                    }
                    DependsOn      = "[xVMHyperV]Create VM $nestedVMName"
                }

                cVMNetworkAdapterSettings "Enable MAC address spoofing and Teaming on $mgmtNetAdapterName of $nestedVMName" {
                    VMName             = $nestedVMName
                    SwitchName         = $VSwitchNameHost
                    Id                 = $mgmtNetAdapterName
                    Name               = $mgmtNetAdapterName
                    AllowTeaming       = 'on'
                    MacAddressSpoofing = 'on'
                    DependsOn          = "[xVMNetworkAdapter]Add network adapter $mgmtNetAdapterName to $nestedVMName"
                }
            }

            # Add converged network adapters.
            1..3 | ForEach-Object -Process {
                $num = $_
                $convergedNetAdapterName = '{0}-Converged{1}' -f $nestedVMName, $num

                xVMNetworkAdapter "Add network adapter $convergedNetAdapterName to $nestedVMName" {
                    Ensure         = 'Present'
                    VMName         = $nestedVMName
                    SwitchName     = $VSwitchNameHost
                    Id             = $convergedNetAdapterName
                    Name           = $convergedNetAdapterName
                    NetworkSetting = xNetworkSettings {
                        IpAddress = '10.10.1{0}.{1}' -f $num, $nestedVMCount
                        Subnet    = "255.255.255.0"
                    }
                    DependsOn      = "[xVMHyperV]Create VM $nestedVMName"
                }
                
                cVMNetworkAdapterSettings "Enable MAC address spoofing and Teaming on $convergedNetAdapterName of $nestedVMName" {
                        VMName             = $nestedVMName
                    SwitchName         = $VSwitchNameHost
                    Id                 = $convergedNetAdapterName
                    Name               = $convergedNetAdapterName
                    AllowTeaming       = 'on'
                    MacAddressSpoofing = 'on'
                    DependsOn          = "[xVMNetworkAdapter]Add network adapter $convergedNetAdapterName to $nestedVMName"
                }
            }

            # unattend.xml for nested VM.
            $unattendXmlFilePath = [IO.Path]::Combine($nestedVMStoreFolderPath, 'unattend.xml')

            Script "Inject unattend XML to $nestedVMName" {
                GetScript = {
                    @{ Result = if ([scriptblock]::Create($TestScript).Invoke()) { 'Present' } else { 'Absent' } }
                }
                SetScript = {
                    $mountResult = Mount-DiskImage -ImagePath $using:osDiskFilePath -StorageType VHDX -Access ReadWrite -ErrorAction Stop
                    $vmWinPartition = Get-Partition -DiskNumber $mountResult.Number | Where-Object -Property 'Type' -EQ -Value 'Basic' | Select-Object -First 1

                    $tempFolderPath = [IO.Path]::Combine($vmWinPartition.DriveLetter + ':\', 'Temp')
                    New-Item -Path $tempFolderPath -ItemType Directory -Force -ErrorAction Stop
                    Copy-Item -Path ([IO.Path]::Combine($using:SourcePath, 'dsc-config-for-nested-vm.ps1')) -Destination $tempFolderPath -Force -ErrorAction Stop

                    $params = @{
                        ComputerName               = $using:nestedVMName
                        LocalAdministratorPassword = $($using:AdminCreds).Password
                        Domain                     = $using:DomainName
                        Username                   = $using:AdminCreds.UserName
                        Password                   = $($using:AdminCreds).Password
                        JoinDomain                 = $using:DomainName
                        AutoLogonCount             = 1
                        OutputPath                 = $using:nestedVMStoreFolderPath
                        Force                      = $true
                        PowerShellScriptFullPath   = 'C:\Temp\dsc-config-for-nested-vm.ps1'
                        ErrorAction                = 'Stop'
                    }
                    New-BasicUnattendXML @params

                    Copy-Item -Path $using:unattendXmlFilePath -Destination ([IO.Path]::Combine($vmWinPartition.DriveLetter + ':\', 'Windows\System32\SysPrep')) -Force -ErrorAction Stop
                    #Start-Sleep -Seconds 2

                    Dismount-DiskImage -ImagePath $mountResult.ImagePath
                }
                TestScript = {
                    Test-Path -Path $using:unattendXmlFilePath -PathType Leaf
                }
                DependsOn = @(
                    "[xVHD]Create OS disk for $nestedVMName",
                    '[Script]Download DSC config script for nested VM'
                )
            }

            Script "Start VM $nestedVMName" {
                GetScript = {
                    @{ Result = if ([scriptblock]::Create($TestScript).Invoke()) { 'Running' } else { 'Not running' } }
                }
                SetScript = {
                    Start-VM -Name $using:nestedVMName
                }
                TestScript = {
                    (Get-VM -Name $using:nestedVMName -ErrorAction SilentlyContinue).State -eq 'Running'
                }
                DependsOn = @(
                    "[Script]Inject unattend XML to $nestedVMName"
                )
            }
        }

    <#
        #### Update AD with Cluster Info ####

        Script 'UpdateAD' {
            GetScript = {
                $result = Test-Path -Path "$using:SourcePath\UpdateAD.txt"
                @{ Result = $result }
            }
            SetScript = {
                Set-Location "$using:SourcePath\"
                .\Update-AD.ps1
                New-item -Path "$using:SourcePath\" -Name "UpdateAD.txt" -ItemType File -Force
            }
            TestScript = {
                # Create and invoke a scriptblock using the $GetScript automatic variable, which contains a string representation of the GetScript.
                $state = [scriptblock]::Create($GetScript).Invoke()
                $state.Result
            }
            DependsOn = @(
                "[Script]Inject unattend XML to $nestedVMName",
                '[ADDomain]Create first DC'
            )
        }

        #### Update WAC Extensions ####

        Script 'WAC Updater' {
            GetScript = {
                # Specify the WAC gateway
                $wac = "https://$env:COMPUTERNAME"

                # Add the module to the current session
                $module = "$env:ProgramFiles\Windows Admin Center\PowerShell\Modules\ExtensionTools\ExtensionTools.psm1"

                Import-Module -Name $module -Verbose -Force
                
                # List the WAC extensions
                $extensions = Get-Extension $wac | Where-Object { $_.isLatestVersion -like 'False' }
                
                $result = if ($extensions.count -gt 0) { $false } else { $true }

                return @{
                    Wac        = $WAC
                    extensions = $extensions
                    result     = $result
                }
            }
            SetScript = {
                $state = [scriptblock]::Create($GetScript).Invoke()
                $date = get-date -f yyyy-MM-dd
                $logFile = Join-Path -Path "C:\Users\Public" -ChildPath $('WACUpdateLog-' + $date + '.log')
                New-Item -Path $logFile -ItemType File -Force
                ForEach ($extension in $state.extensions) {    
                    Update-Extension $state.wac -ExtensionId $extension.Id -Verbose | Out-File -Append -FilePath $logFile -Force
                }
            }
            TestScript = {
                # Create and invoke a scriptblock using the $GetScript automatic variable, which contains a string representation of the GetScript.
                $state = [scriptblock]::Create($GetScript).Invoke()
                return $state.Result
            }
        }
        #>

        #### INSTALL CHOCO, DEPLOY EDGE and Shortcuts

        cChocoInstaller 'Install Choco' {
            InstallDir = 'C:\choco'
        }
            
        cChocoFeature 'Allow global confirmation' {
            Ensure      = 'Present'
            FeatureName = 'allowGlobalConfirmation'
            DependsOn   = '[cChocoInstaller]Install Choco'
        }
        
        cChocoFeature 'Use remembered arguments for upgrades' {
            Ensure      = 'Present'
            FeatureName = 'useRememberedArgumentsForUpgrades'
            DependsOn   = '[cChocoInstaller]Install Choco'
        }
        
        cShortcut 'WAC Shortcut' {
            Path      = 'C:\Users\Public\Desktop\Windows Admin Center.lnk'
            Target    = 'C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe'
            Arguments = 'https://{0}' -f $env:ComputerName
            Icon      = 'shell32.dll,34'
        }
    }
}
