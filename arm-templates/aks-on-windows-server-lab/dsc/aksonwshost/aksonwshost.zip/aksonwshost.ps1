Configuration aksonwshost {
    param (
        [Parameter(Mandatory = $true)]
        [string] $DomainName,

        [Parameter(Mandatory = $true)]
        [string] $Environment,

        [Parameter(Mandatory = $true)]
        [System.Management.Automation.PSCredential] $Admincreds,

        [Parameter(Mandatory = $true)]
        [string] $EnableDHCP,

        [Parameter(Mandatory = $true)]
        [string] $CustomRdpPort,

        [Parameter(Mandatory = $false)]
        [string] $VSwitchNameHost = 'InternalNAT',

        [Parameter(Mandatory = $false)]
        [string] $TargetDrive = 'V',

        [Parameter(Mandatory = $false)]
        [string] $SourcePath = [IO.Path]::Combine($TargetDrive + ':\', 'Source'),

        [Parameter(Mandatory = $false)]
        [string] $UpdatePath = [IO.Path]::Combine($SourcePath, 'Updates'),

        [Parameter(Mandatory = $false)]
        [string] $SsuPath = [IO.Path]::Combine($UpdatePath, 'SSU'),

        [Parameter(Mandatory = $false)]
        [string] $CuPath = [IO.Path]::Combine($UpdatePath, 'CU'),

        [Parameter(Mandatory = $false)]
        [string] $TargetVMPath = [IO.Path]::Combine($TargetDrive + ':\', 'VMs'),

        [Parameter(Mandatory = $false)]
        [string] $WitnessPath = [IO.Path]::Combine($TargetDrive + ':\', 'Witness'),

        [Parameter(Mandatory = $false)]
        [string] $TargetADPath = [IO.Path]::Combine($TargetDrive + ':\', 'ADDS'),

        [Parameter(Mandatory = $false)]
        [string] $BaseVHDFolderPath = [IO.Path]::Combine($TargetVMPath, 'Base'),

        [Parameter(Mandatory = $false)]
        [string] $IsoFileUri = 'https://go.microsoft.com/fwlink/p/?LinkID=2195280&clcid=0x409&culture=en-us&country=US',  # Windows Server 2022 Evaluation

        [Parameter(Mandatory = $false)]
        [string] $NestedVMVhdPath = [IO.Path]::Combine($BaseVHDFolderPath, 'windows-server.vhdx'),

        [Parameter(Mandatory = $false)]
        [string] $LocalIsoFilePath = [IO.Path]::Combine($SourcePath, 'windows-server.iso'),

        [Parameter(Mandatory = $false)]
        [int] $NestedVMCount = 2,

        [Parameter(Mandatory = $false)]
        [int] $NestedVMDataDiskCount = 4,

        [Parameter(Mandatory = $false)]
        [long] $NestedVMDataDiskSize = 250GB
    )
    
    Import-DscResource -ModuleName 'PSDesiredStateConfiguration'
    Import-DscResource -ModuleName 'xPSDesiredStateConfiguration'
    Import-DscResource -ModuleName 'ComputerManagementDsc'
    Import-DscResource -ModuleName 'xHyper-v'
    Import-DscResource -ModuleName 'cHyper-v'
    Import-DscResource -ModuleName 'StorageDSC'
    Import-DscResource -ModuleName 'NetworkingDSC'
    Import-DscResource -ModuleName 'xDHCpServer'
    Import-DscResource -ModuleName 'DnsServerDsc'
    Import-DscResource -ModuleName 'cChoco'
    Import-DscResource -ModuleName 'DSCR_Shortcut'
    Import-DscResource -ModuleName 'xCredSSP'
    Import-DscResource -ModuleName 'ActiveDirectoryDsc'

    $nestedVMDscScriptUri = 'https://raw.githubusercontent.com/tksh164/azure-demo-scripts-templates/master/arm-templates/aks-on-windows-server-lab/dsc/helpers/dsc-config-for-nested-vm.ps1'
    $updateAddsScriptUri = 'https://raw.githubusercontent.com/tksh164/azure-demo-scripts-templates/master/arm-templates/aks-on-windows-server-lab/dsc/helpers/update-adds-config.ps1'

    $dhcpStatus = if ($enableDHCP -eq 'Enabled') { 'Active' } else { 'Inactive' }

    [System.Management.Automation.PSCredential] $DomainCreds = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($Admincreds.UserName)", $Admincreds.Password)

    $ipConfig = (Get-NetAdapter -Physical | Where-Object { $_.InterfaceDescription -like '*Hyper-V*' } | Get-NetIPConfiguration | Where-Object IPv4DefaultGateway)
    $netAdapters = Get-NetAdapter -Name ($ipConfig.InterfaceAlias) | Select-Object -First 1
    $InterfaceAlias = $($netAdapters.Name)

    Node 'localhost' {
        LocalConfigurationManager {
            ConfigurationMode  = 'ApplyOnly'
            RebootNodeIfNeeded = $true
            ActionAfterReboot  = 'ContinueConfiguration'
        }

        #### CREATE STORAGE SPACES V: & VM FOLDER ####

        $storagePoolName = 'aksonwspool'
        $volumeLabel = 'aksonws-data'
    
        Script 'StoragePool' {
            GetScript = {
                @{ Result = if ((Get-StoragePool -FriendlyName $using:storagePoolName).OperationalStatus -eq 'OK') { 'Present' } else { 'Absent' } }
            }
            SetScript = {
                New-StoragePool -FriendlyName $using:storagePoolName -StorageSubSystemFriendlyName '*storage*' -PhysicalDisks (Get-PhysicalDisk -CanPool $true)
            }
            TestScript = {
                (Get-StoragePool -FriendlyName $using:storagePoolName -ErrorAction SilentlyContinue).OperationalStatus -eq 'OK'
            }
        }

        Script 'Volume' {
            GetScript = {
                @{ Result = if ((Get-Volume -DriveLetter $using:TargetDrive).OperationalStatus -eq 'OK') { 'Present' } else { 'Absent' } }
            }
            SetScript = {
                New-Volume -StoragePoolFriendlyName $using:storagePoolName -FileSystem NTFS -AllocationUnitSize 64KB -ResiliencySettingName Simple -UseMaximumSize -DriveLetter $using:TargetDrive -FriendlyName $using:volumeLabel
            }
            TestScript = {
                (Get-Volume -DriveLetter $using:TargetDrive -ErrorAction SilentlyContinue).OperationalStatus -eq 'OK'
            }
        }

        File 'Source' {
            DestinationPath = $SourcePath
            Type            = 'Directory'
            Force           = $true
            DependsOn       = '[Script]Volume'
        }

        File 'Updates' {
            DestinationPath = $UpdatePath
            Type            = 'Directory'
            Force           = $true
            DependsOn       = '[File]Source'
        }

        File 'CU' {
            DestinationPath = $CuPath
            Type            = 'Directory'
            Force           = $true
            DependsOn       = '[File]Updates'
        }

        File 'SSU' {
            DestinationPath = $SsuPath
            Type            = 'Directory'
            Force           = $true
            DependsOn       = '[File]Updates'
        }

        File 'VMFolder' {
            Type            = 'Directory'
            DestinationPath = $TargetVMPath
            DependsOn       = '[Script]Volume'
        }

        File 'VMBase' {
            Type            = 'Directory'
            DestinationPath = $BaseVHDFolderPath
            DependsOn       = '[File]VMFolder'
        }

        File 'WitnessFolder' {
            Type            = 'Directory'
            DestinationPath = $WitnessPath
            DependsOn       = '[Script]Volume'
        }

        if ($environment -eq 'AD Domain') {
            File 'ADFolder' {
                Type            = 'Directory'
                DestinationPath = $TargetADPath
                DependsOn       = '[Script]Volume'
            }
        }

        Script 'Download the DSC config script for nested VMs' {
            GetScript = {
                @{ Result = Test-Path -Path ([IO.Path]::Combine($using:SourcePath, 'dsc-config-for-nested-vm.ps1')) }
            }
            SetScript = {
                Start-BitsTransfer -Source $using:nestedVMDscScriptUri -Destination ([IO.Path]::Combine($using:SourcePath, 'dsc-config-for-nested-vm.ps1'))
            }
            TestScript = {
                # Create and invoke a scriptblock using the $GetScript automatic variable, which contains a string representation of the GetScript.
                $state = [scriptblock]::Create($GetScript).Invoke()
                $state.Result
            }
            DependsOn = '[File]Source'
        }

        Script 'Download the update AD DS configuration script' {
            GetScript = {
                @{ Result = Test-Path -Path ([IO.Path]::Combine($using:SourcePath, 'update-adds-config.ps1')) }
            }
            SetScript = {
                Start-BitsTransfer -Source $using:updateAddsScriptUri -Destination ([IO.Path]::Combine($using:SourcePath, 'update-adds-config.ps1'))        
            }
            TestScript = {
                # Create and invoke a scriptblock using the $GetScript automatic variable, which contains a string representation of the GetScript.
                $state = [scriptblock]::Create($GetScript).Invoke()
                $state.Result
            }
            DependsOn = '[File]Source'
        }

        Script 'Download ISO file' {
            GetScript = {
                @{ Result = Test-Path -Path $using:LocalIsoFilePath }
            }
            SetScript = {
                Start-BitsTransfer -Source $using:IsoFileUri -Destination $using:LocalIsoFilePath
            }
            TestScript = {
                # Create and invoke a scriptblock using the $GetScript automatic variable, which contains a string representation of the GetScript.
                $state = [scriptblock]::Create($GetScript).Invoke()
                $state.Result
            }
            DependsOn = '[File]Source'
        }

        <#
        Script 'Download AzSHCI SSU' {
            GetScript = {
                $result = Test-Path -Path "$using:SsuPath\*" -Include "*.msu"
                @{ Result = $result }
            }
            SetScript = {
                $ssuSearchString = "Servicing Stack Update for Azure Stack HCI, version 21H2 for x64-based Systems"
                $ssuID = "Azure Stack HCI"
                $ssuUpdate = Get-MSCatalogUpdate -Search $ssuSearchString | Where-Object Products -eq $ssuID | Select-Object -First 1
                $ssuUpdate | Save-MSCatalogUpdate -Destination $using:SsuPath
            }
            TestScript = {
                # Create and invoke a scriptblock using the $GetScript automatic variable, which contains a string representation of the GetScript.
                $state = [scriptblock]::Create($GetScript).Invoke()
                $state.Result
            }
            DependsOn = '[File]SSU'
        }
        #>

        <#
        Script 'Download AzSHCI CU' {
            GetScript = {
                $result = Test-Path -Path "$using:CuPath\*" -Include "*.msu"
                @{ Result = $result }
            }
            SetScript = {
                $cuSearchString = "Cumulative Update for Azure Stack HCI, version 21H2"
                $cuID = "Azure Stack HCI"
                $cuUpdate = Get-MSCatalogUpdate -Search $cuSearchString | Where-Object Products -eq $cuID | Where-Object Title -like "*$($cuSearchString)*" | Select-Object -First 1
                $cuUpdate | Save-MSCatalogUpdate -Destination $using:CuPath
            }
            TestScript = {
                # Create and invoke a scriptblock using the $GetScript automatic variable, which contains a string representation of the GetScript.
                $state = [scriptblock]::Create($GetScript).Invoke()
                $state.Result
            }
            DependsOn = '[File]CU'
        }
        #>

        #### SET WINDOWS DEFENDER EXCLUSION FOR VM STORAGE ####

        $exclusionPath = $TargetDrive + ':\'

        Script 'Defender Exclusions' {
            GetScript = {
                @{ Result = if ((Get-MpPreference).ExclusionPath -contains $using:exclusionPath) { 'Present' } else { 'Absent' } }
            }
            SetScript = {
                Add-MpPreference -ExclusionPath $using:exclusionPath      
            }
            TestScript = {
                (Get-MpPreference).ExclusionPath -contains $using:exclusionPath
            }
            DependsOn  = '[Script]Volume'
        }

        #### REGISTRY & SCHEDULED TASK TWEAKS ####

        Registry 'Disable Internet Explorer ESC for Admin' {
            Ensure    = 'Present'
            Key       = 'HKLM:\SOFTWARE\Microsoft\Active Setup\Installed Components\{A509B1A7-37EF-4b3f-8CFC-4F3A74704073}'
            ValueName = 'IsInstalled'
            ValueType = 'Dword'
            ValueData = '0'
        }

        Registry 'Disable Internet Explorer ESC for User' {
            Ensure    = 'Present'
            Key       = 'HKLM:\SOFTWARE\Microsoft\Active Setup\Installed Components\{A509B1A8-37EF-4b3f-8CFC-4F3A74704073}'
            ValueName = 'IsInstalled'
            ValueType = 'Dword'
            ValueData = '0'
        }
        
        Registry 'Disable Server Manager WAC Prompt' {
            Ensure    = 'Present'
            Key       = 'HKLM:\SOFTWARE\Microsoft\ServerManager'
            ValueName = 'DoNotPopWACConsoleAtSMLaunch'
            ValueType = 'Dword'
            ValueData = '1'
        }

        Registry 'Disable Network Profile Prompt' {
            Ensure    = 'Present'
            Key       = 'HKLM:\System\CurrentControlSet\Control\Network\NewNetworkWindowOff'
            ValueName = ''
        }

        if ($environment -eq 'Workgroup') {
            Registry 'Set Network Private Profile Default' {
                Ensure    = 'Present'
                Key       = 'HKLM:\SOFTWARE\Policies\Microsoft\Windows NT\CurrentVersion\NetworkList\Signatures\010103000F0000F0010000000F0000F0C967A3643C3AD745950DA7859209176EF5B87C875FA20DF21951640E807D7C24'
                ValueName = 'Category'
                ValueType = 'Dword'
                ValueData = '1'
            }
    
            Registry 'SetWorkgroupDomain' {
                Ensure    = 'Present'
                Key       = 'HKLM:\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters'
                ValueName = 'Domain'
                ValueType = 'String'
                ValueData = $DomainName
            }
    
            Registry 'SetWorkgroupNVDomain' {
                Ensure    = 'Present'
                Key       = 'HKLM:\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters'
                ValueName = 'NV Domain'
                ValueType = 'String'
                ValueData = $DomainName
            }
    
            Registry 'NewCredSSPKey' {
                Ensure    = 'Present'
                Key       = 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\CredentialsDelegation\AllowFreshCredentialsWhenNTLMOnly'
                ValueName = ''
            }
    
            Registry 'NewCredSSPKey2' {
                Ensure    = 'Present'
                Key       = 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\CredentialsDelegation'
                ValueName = 'AllowFreshCredentialsWhenNTLMOnly'
                ValueType = 'Dword'
                ValueData = '1'
                DependsOn = '[Registry]NewCredSSPKey'
            }
    
            Registry 'NewCredSSPKey3' {
                Ensure    = 'Present'
                Key       = 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\CredentialsDelegation\AllowFreshCredentialsWhenNTLMOnly'
                ValueName = '1'
                ValueType = 'String'
                ValueData = '*.{0}' -f $DomainName
                DependsOn = '[Registry]NewCredSSPKey2'
            }
        }

        ScheduledTask 'Disable Server Manager at Startup' {
            TaskPath = '\Microsoft\Windows\Server Manager'
            TaskName = 'ServerManager'
            Enable   = $false
        }

        #### CUSTOM FIREWALL BASED ON ARM TEMPLATE ####

        if ($customRdpPort -ne '3389') {
            Registry 'Set Custom RDP Port' {
                Ensure    = 'Present'
                Key       = 'HKLM:\SYSTEM\CurrentControlSet\Control\Terminal Server\WinStations\RDP-Tcp'
                ValueName = 'PortNumber'
                ValueData = $customRdpPort
                ValueType = 'Dword'
            }
        
            Firewall 'AddFirewallRule' {
                Name        = 'CustomRdpRule'
                DisplayName = 'Custom Rule for RDP'
                Ensure      = 'Present'
                Enabled     = 'True'
                Profile     = 'Any'
                Direction   = 'Inbound'
                LocalPort   = $customRdpPort
                Protocol    = 'TCP'
                Description = 'Firewall Rule for Custom RDP Port'
            }
        }

        #### ENABLE ROLES & FEATURES ####

        WindowsFeatureSet 'Install roles and features' {
            Ensure = 'Present'
            Name = @(
                'DNS',
                'RSAT-DNS-Server',
                'DHCP',
                'RSAT-DHCP',
                'RSAT-Clustering',
                'Hyper-V',
                'RSAT-Hyper-V-Tools',
                'FS-Data-Deduplication'
            )
        }

        Script 'Enable DNS diags' {
            GetScript = { @{ Result = '' } }
            SetScript = { 
                Set-DnsServerDiagnostics -All $true
                Write-Verbose -Verbose 'Enabling DNS client diagnostics'
            }
            TestScript = { $false }
            DependsOn = '[WindowsFeatureSet]Install roles and features'
        }

        DnsServerAddress "DnsServerAddress for $InterfaceAlias" {
            Address        = '127.0.0.1'
            InterfaceAlias = $InterfaceAlias
            AddressFamily  = 'IPv4'
            DependsOn      = '[WindowsFeatureSet]Install roles and features'
        }

        Registry 'DHCP config complete' {
            Ensure    = 'Present'
            Key       = 'HKLM:\SOFTWARE\Microsoft\ServerManager\Roles\12'
            ValueName = 'ConfigurationState'
            ValueType = 'Dword'
            ValueData = '2'
            DependsOn = '[WindowsFeatureSet]Install roles and features'
        }

        if ($environment -eq 'AD Domain') {
            WindowsFeatureSet 'Install AD DS' {
                Ensure = 'Present'
                Name = @(
                    'AD-Domain-Services',
                    'RSAT-ADDS-Tools',
                    'RSAT-AD-AdminCenter'
                )
                DependsOn = '[WindowsFeatureSet]Install roles and features'
            }

            ADDomain 'Create first DC' {
                DomainName                    = $DomainName
                Credential                    = $DomainCreds
                SafemodeAdministratorPassword = $DomainCreds
                DatabasePath                  = [IO.Path]::Combine($TargetADPath, 'NTDS')
                LogPath                       = [IO.Path]::Combine($TargetADPath, 'NTDS')
                SysvolPath                    = [IO.Path]::Combine($TargetADPath, 'SYSVOL')
                DependsOn                     = @(
                    '[File]ADFolder',
                    '[WindowsFeatureSet]Install AD DS'
                )
            }
        }

        #### HYPER-V vSWITCH CONFIG ####

        xVMHost 'Hyper-V Host'
        {
            IsSingleInstance          = 'yes'
            EnableEnhancedSessionMode = $true
            VirtualHardDiskPath       = $TargetVMPath
            VirtualMachinePath        = $TargetVMPath
            DependsOn                 = '[WindowsFeatureSet]Install roles and features'
        }

        xVMSwitch 'Create NAT vSwitch'
        {
            Name      = $VSwitchNameHost
            Type      = 'Internal'
            DependsOn = '[WindowsFeatureSet]Install roles and features'
        }

        $natInterfaceName = 'vEthernet ({0})' -f $VSwitchNameHost

        IPAddress 'Assign IP address for NAT network interface'
        {
            InterfaceAlias = $natInterfaceName
            AddressFamily  = 'IPv4'
            IPAddress      = '192.168.0.1/16'
            DependsOn      = '[xVMSwitch]Create NAT vSwitch'
        }

        NetIPInterface 'Enable IP forwarding on NAT network interface'
        {   
            AddressFamily  = 'IPv4'
            InterfaceAlias = $natInterfaceName
            Forwarding     = 'Enabled'
            DependsOn      = '[IPAddress]Assign IP address for NAT network interface'
        }

        NetAdapterRdma 'Enable RDMA on NAT network interface'
        {
            Name      = $natInterfaceName
            Enabled   = $true
            DependsOn = '[NetIPInterface]Enable IP forwarding on NAT network interface'
        }

        DnsServerAddress 'Set DNS server address for NAT network interface'
        { 
            Address        = '127.0.0.1' 
            InterfaceAlias = $natInterfaceName
            AddressFamily  = 'IPv4'
            DependsOn      = '[IPAddress]Assign IP address for NAT network interface'
        }

        if ($environment -eq 'AD Domain') {
            xDhcpServerAuthorization 'Authorize DHCP server' {
                Ensure    = 'Present'
                DnsName   = [System.Net.Dns]::GetHostByName($env:computerName).hostname
                IPAddress = '192.168.0.1'
                DependsOn = '[WindowsFeatureSet]Install roles and features'
            }
        }
        elseif ($environment -eq 'Workgroup') {
            NetConnectionProfile 'Set network connection profile' {
                InterfaceAlias  = $InterfaceAlias
                NetworkCategory = 'Private'
            }
        }

        #### PRIMARY NIC CONFIG ####

        NetAdapterBinding 'Disable IPv6 on host network interface' {
            InterfaceAlias = $InterfaceAlias
            ComponentId    = 'ms_tcpip6'
            State          = 'Disabled'
        }

        #### CONFIGURE Interna NAT NIC

        $netNatName = 'lab-nat'

        Script 'Create network NAT' {
            GetScript = {
                @{ Result = if (Get-NetNat -Name $using:netNatName -ErrorAction SilentlyContinue) { $true } else { $false } }
            }
            SetScript = {
                New-NetNat -Name $using:netNatName -InternalIPInterfaceAddressPrefix '192.168.0.0/16'
            }
            TestScript = {
                # Create and invoke a scriptblock using the $GetScript automatic variable, which contains a string representation of the GetScript.
                $state = [scriptblock]::Create($GetScript).Invoke()
                return $state.Result
            }
            DependsOn = '[IPAddress]Assign IP address for NAT network interface'
        }

        NetAdapterBinding 'Disable IPv6 on NAT network interface' {
            InterfaceAlias = $natInterfaceName
            ComponentId    = 'ms_tcpip6'
            State          = 'Disabled'
            DependsOn      = '[Script]Create network NAT'
        }

        #### CONFIGURE DHCP SERVER

        xDhcpServerScope 'Create DHCP scope' { 
            Ensure        = 'Present'
            IPStartRange  = '192.168.0.10'
            IPEndRange    = '192.168.0.149' 
            ScopeId       = '192.168.0.0'
            Name          = 'Lab Range'
            SubnetMask    = '255.255.0.0'
            LeaseDuration = '01.00:00:00'
            State         = $dhcpStatus
            AddressFamily = 'IPv4'
            DependsOn     = @(
                '[WindowsFeatureSet]Install roles and features',
                '[IPAddress]Assign IP address for NAT network interface'
            )
        }

        xDhcpServerOption 'Set DHCP server option' { 
            Ensure             = 'Present' 
            ScopeID            = '192.168.0.0' 
            DnsDomain          = $DomainName
            DnsServerIPAddress = '192.168.0.1'
            AddressFamily      = 'IPv4'
            Router             = '192.168.0.1'
            DependsOn          = '[xDhcpServerScope]Create DHCP scope'
        }

        if ($environment -eq 'AD Domain') {
            DnsServerPrimaryZone 'Set reverse lookup zone' {
                Ensure    = 'Present'
                Name      = '0.168.192.in-addr.arpa'
                ZoneFile  = '0.168.192.in-addr.arpa.dns'
                DependsOn = '[ADDomain]Create first DC'
            }
        }
        elseif ($environment -eq 'Workgroup') {
            DnsServerPrimaryZone 'Set primary DNS zone' {
                Ensure        = 'Present'
                Name          = $DomainName
                ZoneFile      = $DomainName + '.dns'
                DynamicUpdate = 'NonSecureAndSecure'
                DependsOn     = '[Script]Create network NAT'
            }
    
            DnsServerPrimaryZone 'Set reverse lookup zone' {
                Ensure        = 'Present'
                Name          = '0.168.192.in-addr.arpa'
                ZoneFile      = '0.168.192.in-addr.arpa.dns'
                DynamicUpdate = 'NonSecureAndSecure'
                DependsOn     = '[DnsServerPrimaryZone]Set primary DNS zone'
            }
        }

        #### FINALIZE DHCP

        Script 'Set DHCP DNS Setting' {
            GetScript = { @{ Result = '' } }
            SetScript = {
                Set-DhcpServerv4DnsSetting -DynamicUpdates 'Always' -DeleteDnsRRonLeaseExpiry $true -UpdateDnsRRForOlderClients $true -DisableDnsPtrRRUpdate $false
                Write-Verbose -Verbose 'Setting server level DNS dynamic update configuration settings'
            }
            TestScript = { $false }
            DependsOn = '[xDhcpServerOption]Set DHCP server option'
        }

        if ($environment -eq 'Workgroup') {
            DnsConnectionSuffix 'Add specific suffix to host network interface' {
                InterfaceAlias           = $InterfaceAlias
                ConnectionSpecificSuffix = $DomainName
                DependsOn                = '[DnsServerPrimaryZone]Set primary DNS zone'
            }
    
            DnsConnectionSuffix 'Add specific suffix to NAT network interface' {
                InterfaceAlias           = $natInterfaceName
                ConnectionSpecificSuffix = $DomainName
                DependsOn                = '[DnsServerPrimaryZone]Set primary DNS zone'
            }

            #### CONFIGURE CREDSSP & WinRM

            xCredSSP 'Set CredSSD Server settings' {
                Ensure         = 'Present'
                Role           = 'Server'
                SuppressReboot = $true
                DependsOn      = '[DnsConnectionSuffix]Add specific suffix to NAT network interface'
            }

            xCredSSP 'Set CredSSD Client settings' {
                Ensure            = 'Present'
                Role              = 'Client'
                DelegateComputers = '{0}.{1}' -f $env:ComputerName, $DomainName
                SuppressReboot    = $true
                DependsOn         = '[xCredSSP]Set CredSSD Server settings'
            }

            #### CONFIGURE WinRM

            $expectedTrustedHost = '*.{0}' -f $DomainName

            Script 'Configure WinRM' {
                GetScript = {
                    @{ Result = if ((Get-Item -LiteralPath 'WSMan:\localhost\Client\TrustedHosts').Value -contains $using:expectedTrustedHost) { 'Present' } else { 'Absent' } }
                }
                SetScript = {
                    Set-Item -LiteralPath 'WSMan:\localhost\Client\TrustedHosts' -Value $using:expectedTrustedHost -Force
                }
                TestScript = {
                    (Get-Item -LiteralPath 'WSMan:\localhost\Client\TrustedHosts').Value -contains $using:expectedTrustedHost
                }
                DependsOn = '[xCredSSP]Set CredSSD Client settings'
            }
        }












        #### Start nested VM creation ####

        Script 'Prepare VHDX' {
            GetScript = {
                @{ Result = Test-Path -Path $using:NestedVMVhdPath }
            }
            SetScript = {
                # Create netsted VM image from ISO
                
                # TODO: Is this need?
                New-Item -Path ([IO.Path]::Combine($using:TargetVMPath, 'Scratch')) -ItemType Directory -Force | Out-Null
                
                $params = @{
                    SourcePath        = $using:LocalIsoFilePath
                    VHDPath           = $using:NestedVMVhdPath
                    VHDFormat         = 'VHDX'
                    VHDType           = 'Dynamic'
                    VHDPartitionStyle = 'GPT'
                    SizeBytes         = 100GB
                    TempDirectory     = $using:TargetVMPath
                    Verbose           = $true
                }

                # Determine if any SSUs are available
                $ssu = Test-Path -Path ([IO.Path]::Combine($using:SsuPath, '*')) -Include '*.msu'
                if ($ssu) {
                    $params.Package = $using:SsuPath
                }

                Convert-WindowsImage @params


                # else {
                #     $params = @{
                #         SourcePath = $using:LocalIsoFilePath
                #         VHDPath = $using:NestedVMVhdPath
                #         VHDFormat = 'VHDX'
                #         VHDType = 'Dynamic'
                #         VHDPartitionStyle = 'GPT'
                #         SizeBytes = 100GB
                #         TempDirectory = $using:TargetVMPath
                #         Verbose = $true
                #     }

                #     Convert-WindowsImage -SourcePath $using:LocalIsoFilePath -SizeBytes 100GB -VHDPath $using:NestedVMVhdPath `
                #         -VHDFormat VHDX -VHDType Dynamic -VHDPartitionStyle GPT -TempDirectory $using:TargetVMPath -Verbose
                # }

                #Convert-Wim2Vhd -DiskLayout UEFI -SourcePath $using:LocalIsoFilePath -Path $using:NestedVMVhdPath -Package $using:SsuPath -Size 100GB -Dynamic -Index 1 -ErrorAction SilentlyContinue

                # Need to wait for disk to fully unmount
                While ((Get-Disk).Count -gt 2) {
                    Start-Sleep -Seconds 5
                }

                Mount-VHD -Path $using:NestedVMVhdPath -Passthru -ErrorAction Stop -Verbose
                Start-Sleep -Seconds 2

                # TODO: Is this need WMI?
                $disks = Get-CimInstance -ClassName 'Win32_DiskDrive' | Where-Object Caption -eq 'Microsoft Virtual Disk'      
                foreach ($disk in $disks) {            
                    $vols = Get-CimAssociatedInstance -CimInstance $disk -ResultClassName 'Win32_DiskPartition'             
                    foreach ($vol in $vols) {            
                        $updatedrive = Get-CimAssociatedInstance -CimInstance $vol -ResultClassName 'Win32_LogicalDisk' |            
                        Where-Object VolumeName -ne 'System Reserved'          
                    }            
                }
                $updatePath = $updatedrive.DeviceID + '\'

                $updates = Get-ChildItem -Path $using:CuPath -Recurse | Where-Object { ($_.Extension -eq '.msu') -or ($_.Extension -eq '.cab') } | Select-Object -Property 'FullName'
                foreach ($update in $updates) {
                    Write-Debug $update.FullName
                    $command = 'dism /image:{0} /add-package /packagepath:"{1}"' -f $updatePath, $update.FullName
                    Write-Debug $command
                    Invoke-Expression -Command $command
                }
            
                $command = "dism /image:{0} /cleanup-image /spsuperseded" -f $updatePath
                Invoke-Expression -Command $command

                Dismount-VHD -Path $using:NestedVMVhdPath -Confirm:$false
                Start-Sleep -Seconds 5

                # Enable Hyper-V role on the nested VM VHD.
                Install-WindowsFeature -Name 'Hyper-V' -Vhd $using:NestedVMVhdPath
            }
            TestScript = {
                # Create and invoke a scriptblock using the $GetScript automatic variable, which contains a string representation of the GetScript.
                $state = [scriptblock]::Create($GetScript).Invoke()
                $state.Result
            }
            DependsOn = @(
                '[File]VMBase',
                '[Script]Download ISO file'#,
                #'[Script]Download AzSHCI SSU',
                #'[Script]Download AzSHCI CU'
            )
        }

        for ($i = 0; $i -lt $NestedVMCount; $i++) {
            $nestedVMName = 'wsfcnode{0:D2}' -f ($i + 1)

            File "VM store folder for $nestedVMName" {
                Ensure          = 'Present'
                DestinationPath = [IO.Path]::Combine($TargetVMPath, $nestedVMName)
                Type            = 'Directory'
                DependsOn       = '[File]VMFolder'
            }
            
            xVHD "NewOSDisk-$nestedVMName"
            {
                Ensure     = 'Present'
                Name       = "$nestedVMName-osdisk.vhdx"
                Path       = "$TargetVMPath\$nestedVMName"
                Generation = 'vhdx'
                ParentPath = $NestedVMVhdPath
                Type       = 'Differencing'
                DependsOn  = @(
                    "[xVMSwitch]$VSwitchNameHost",
                    '[Script]Prepare VHDX',
                    "[File]VM store folder for $nestedVMName"
                )
            }

            xVMHyperV "VM-$nestedVMName"
            {
                Ensure         = 'Present'
                Name           = $nestedVMName
                VhdPath        = "$TargetVMPath\$nestedVMName\$nestedVMName-osdisk.vhdx"
                Path           = $TargetVMPath
                Generation     = 2
                StartupMemory  = 24GB
                ProcessorCount = 8
                DependsOn      = "[xVhd]NewOSDisk-$nestedVMName"
            }

            xVMProcessor 'Enable NestedVirtualization-$nestedVMName'
            {
                VMName                         = $nestedVMName
                ExposeVirtualizationExtensions = $true
                DependsOn                      = "[xVMHyperV]VM-$nestedVMName"
            }

            Script "remove default Network Adapter on VM-$nestedVMName" {
                GetScript = {
                    $VMNetworkAdapter = Get-VMNetworkAdapter -VMName $using:vmname -Name 'Network Adapter' -ErrorAction SilentlyContinue
                    $result = if ($VMNetworkAdapter) { $false } else { $true }
                    @{
                        VMName = $VMNetworkAdapter.VMName
                        Name   = $VMNetworkAdapter.Name
                        Result = $result
                    }
                }
                SetScript = {
                    $state = [scriptblock]::Create($GetScript).Invoke()
                    Remove-VMNetworkAdapter -VMName $state.VMName -Name $state.Name                 
                }
                TestScript = {
                    # Create and invoke a scriptblock using the $GetScript automatic variable, which contains a string representation of the GetScript.
                    $state = [scriptblock]::Create($GetScript).Invoke()
                    $state.Result
                }
                DependsOn = "[xVMHyperV]VM-$nestedVMName"
            }

            for ($k = 1; $k -le 1; $k++) {
                $ipAddress = $('192.168.0.' + ($i + 1))
                $mgmtNicName = "$nestedVMName-Management$k"

                xVMNetworkAdapter "New Network Adapter $mgmtNicName $nestedVMName DHCP" {
                    Id         = $mgmtNicName
                    Name       = $mgmtNicName
                    SwitchName = $VSwitchNameHost
                    VMName     = $nestedVMName
                    NetworkSetting = xNetworkSettings {
                        IpAddress      = $ipAddress
                        Subnet         = "255.255.0.0"
                        DefaultGateway = "192.168.0.1"
                        DnsServer      = "192.168.0.1"
                    }
                    Ensure     = 'Present'
                    DependsOn  = "[xVMHyperV]VM-$nestedVMName"
                }

                cVMNetworkAdapterSettings "Enable $nestedVMName $mgmtNicName Mac address spoofing and Teaming" {
                    Id                 = $mgmtNicName
                    Name               = $mgmtNicName
                    SwitchName         = $VSwitchNameHost
                    VMName             = $nestedVMName
                    AllowTeaming       = 'on'
                    MacAddressSpoofing = 'on'
                    DependsOn          = "[xVMNetworkAdapter]New Network Adapter $mgmtNicName $nestedVMName DHCP"
                }
            }

            for ($l = 1; $l -le 3; $l++) {
                $ipAddress = $('10.10.1' + $l + '.' + $i)
                $nicName = "$nestedVMName-ConvergedNic$l"

                xVMNetworkAdapter "New Network Adapter Converged $nestedVMName $nicName $ipAddress" {
                    Id         = $nicName
                    Name       = $nicName
                    SwitchName = $VSwitchNameHost
                    VMName     = $nestedVMName
                    NetworkSetting = xNetworkSettings {
                        IpAddress = $ipAddress
                        Subnet    = "255.255.255.0"
                    }
                    Ensure     = 'Present'
                    DependsOn  = "[xVMHyperV]VM-$nestedVMName"
                }
                
                cVMNetworkAdapterSettings "Enable $nestedVMName $nicName Mac address spoofing and Teaming" {
                    Id                 = $nicName
                    Name               = $nicName
                    SwitchName         = $VSwitchNameHost
                    VMName             = $nestedVMName
                    AllowTeaming       = 'on'
                    MacAddressSpoofing = 'on'
                    DependsOn          = "[xVMNetworkAdapter]New Network Adapter Converged $nestedVMName $nicName $ipAddress"
                }
            }

            for ($j = 1; $j -lt $NestedVMDataDiskCount + 1 ; $j++) {
                xVHD "$nestedVMName-DataDisk$j" {
                    Ensure           = 'Present'
                    Name             = "$nestedVMName-DataDisk$j.vhdx"
                    Path             = "$TargetVMPath\$nestedVMName"
                    Generation       = 'vhdx'
                    Type             = 'Dynamic'
                    MaximumSizeBytes = $NestedVMDataDiskSize
                    DependsOn        = "[xVMHyperV]VM-$nestedVMName"
                }
            
                xVMHardDiskDrive "$nestedVMName-DataDisk$j" {
                    VMName             = $nestedVMName
                    ControllerType     = 'SCSI'
                    ControllerLocation = $j
                    Path               = "$TargetVMPath\$nestedVMName\$nestedVMName-DataDisk$j.vhdx"
                    Ensure             = 'Present'
                    DependsOn          = "[xVMHyperV]VM-$nestedVMName"
                }
            }

            Script "UnattendXML for $nestedVMName" {
                GetScript = {
                    $name = $using:vmname
                    $result = Test-Path -Path "$using:TargetVMPath\$name\Unattend.xml"
                    @{ Result = $result }
                }
                SetScript = {
                    try {
                        $name = $using:vmname
                        $mount = Mount-VHD -Path "$using:TargetVMPath\$name\$name-OSDisk.vhdx" -Passthru -ErrorAction Stop -Verbose
                        Start-Sleep -Seconds 2
                        $driveLetter = $mount | Get-Disk | Get-Partition | Get-Volume | Where-Object DriveLetter | Select-Object -ExpandProperty DriveLetter
                        
                        New-Item -Path $("$driveLetter" + ":" + "\Temp") -ItemType Directory -Force -ErrorAction Stop
                        Copy-Item -Path "$using:SourcePath\Install-AzsRolesandFeatures.ps1" -Destination $("$driveLetter" + ":" + "\Temp") -Force -ErrorAction Stop
                        
                        New-BasicUnattendXML -ComputerName $name -LocalAdministratorPassword $($using:Admincreds).Password -Domain $using:DomainName -Username $using:Admincreds.Username `
                            -Password $($using:Admincreds).Password -JoinDomain $using:DomainName -AutoLogonCount 1 -OutputPath "$using:TargetVMPath\$name" -Force `
                            -PowerShellScriptFullPath 'c:\temp\Install-AzsRolesandFeatures.ps1' -ErrorAction Stop

                        Copy-Item -Path "$using:TargetVMPath\$name\Unattend.xml" -Destination $("$driveLetter" + ":" + "\Windows\system32\SysPrep") -Force -ErrorAction Stop

                        Start-Sleep -Seconds 2
                    }
                    finally {
                        Dismount-VHD -Path "$using:TargetVMPath\$name\$name-OSDisk.vhdx"
                    }
                    Start-VM -Name $name
                }
                TestScript = {
                    # Create and invoke a scriptblock using the $GetScript automatic variable, which contains a string representation of the GetScript.
                    $state = [scriptblock]::Create($GetScript).Invoke()
                    $state.Result
                }
                DependsOn = @(
                    "[xVHD]NewOSDisk-$nestedVMName",
                    '[Script]Download DSC Config for AzsHci Hosts'
                )
            }
        }

        #### Update AD with Cluster Info ####

        Script 'UpdateAD' {
            GetScript = {
                $result = Test-Path -Path "$using:SourcePath\UpdateAD.txt"
                @{ Result = $result }
            }
            SetScript = {
                Set-Location "$using:SourcePath\"
                .\Update-AD.ps1
                New-item -Path "$using:SourcePath\" -Name "UpdateAD.txt" -ItemType File -Force
            }
            TestScript = {
                # Create and invoke a scriptblock using the $GetScript automatic variable, which contains a string representation of the GetScript.
                $state = [scriptblock]::Create($GetScript).Invoke()
                $state.Result
            }
            DependsOn = @(
                "[script]UnattendXML for $nestedVMName",
                '[ADDomain]Create first DC'
            )
        }

        #### Update WAC Extensions ####

        Script 'WAC Updater' {
            GetScript = {
                # Specify the WAC gateway
                $wac = "https://$env:COMPUTERNAME"

                # Add the module to the current session
                $module = "$env:ProgramFiles\Windows Admin Center\PowerShell\Modules\ExtensionTools\ExtensionTools.psm1"

                Import-Module -Name $module -Verbose -Force
                
                # List the WAC extensions
                $extensions = Get-Extension $wac | Where-Object { $_.isLatestVersion -like 'False' }
                
                $result = if ($extensions.count -gt 0) { $false } else { $true }

                return @{
                    Wac        = $WAC
                    extensions = $extensions
                    result     = $result
                }
            }
            SetScript = {
                $state = [scriptblock]::Create($GetScript).Invoke()
                $date = get-date -f yyyy-MM-dd
                $logFile = Join-Path -Path "C:\Users\Public" -ChildPath $('WACUpdateLog-' + $date + '.log')
                New-Item -Path $logFile -ItemType File -Force
                ForEach ($extension in $state.extensions) {    
                    Update-Extension $state.wac -ExtensionId $extension.Id -Verbose | Out-File -Append -FilePath $logFile -Force
                }
            }
            TestScript = {
                # Create and invoke a scriptblock using the $GetScript automatic variable, which contains a string representation of the GetScript.
                $state = [scriptblock]::Create($GetScript).Invoke()
                return $state.Result
            }
        }

        #### INSTALL CHOCO, DEPLOY EDGE and Shortcuts

        cChocoInstaller 'InstallChoco' {
            InstallDir = 'C:\choco'
        }
            
        cChocoFeature 'AllowGlobalConfirmation' {
            FeatureName = 'allowGlobalConfirmation'
            Ensure      = 'Present'
            DependsOn   = '[cChocoInstaller]InstallChoco'
        }
        
        cChocoFeature 'UseRememberedArgumentsForUpgrades' {
            FeatureName = 'useRememberedArgumentsForUpgrades'
            Ensure      = 'Present'
            DependsOn   = '[cChocoInstaller]InstallChoco'
        }
        
        cChocoPackageInstaller 'Install Chromium Edge' {
            Name        = 'microsoft-edge'
            Ensure      = 'Present'
            AutoUpgrade = $true
            DependsOn   = '[cChocoInstaller]InstallChoco'
        }

        cShortcut 'WAC Shortcut' {
            Path      = 'C:\Users\Public\Desktop\Windows Admin Center.lnk'
            Target    = 'C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe'
            Arguments = "https://$env:computerName"
            Icon      = 'shell32.dll,34'
        }

        #### STAGE 3c - Update Firewall

        Firewall 'WACInboundRule' {
            Name        = 'WACInboundRule'
            DisplayName = 'Allow Windows Admin Center'
            Ensure      = 'Present'
            Enabled     = 'True'
            Profile     = 'Any'
            Direction   = 'Inbound'
            LocalPort   = "443"
            Protocol    = 'TCP'
            Description = 'Allow Windows Admin Center'
        }

        Firewall 'WACOutboundRule' {
            Name        = 'WACOutboundRule'
            DisplayName = 'Allow Windows Admin Center'
            Ensure      = 'Present'
            Enabled     = 'True'
            Profile     = 'Any'
            Direction   = 'Outbound'
            LocalPort   = "443"
            Protocol    = 'TCP'
            Description = 'Allow Windows Admin Center'
        }
        #>

    }
}
